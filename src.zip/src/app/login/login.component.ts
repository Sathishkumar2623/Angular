import { Component, OnInit } from '@angular/core';
import { Service } from '../services.service';
import { user } from '../Types/User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: user = {
    firstName: '',
    lastName: '',
    contactNumber: '',
    alternateNumber: '',
    email:'',
    userId: '',
    password: '',
    role: '',
    userName: '',

  }
  constructor(private services: Service) { }

  ngOnInit(): void {
  }

  onFormSubmit() {
    this.services.login(this.user).subscribe(data => {
      if (data.status == 200) {
        alert("Logged In")
      }
    }, () => {
      alert("User ID or Password is incorrect")
    })
  }

}
