import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { user } from './Types/User';

@Injectable({
  providedIn: 'root'
})
export class Service {

  constructor(private http: HttpClient) {
  }

  root_url = "http://localhost:9090/";

  getUser() {
    return this.http.get<user>(this.root_url + "User");
  }

  postUser(user: user) {
    const headers = { 'content-type': 'application/json' }
    const body = JSON.stringify(user);
    return this.http.post<user>(this.root_url + "User", body, { 'headers': headers, 'observe': 'response' });
  }

  login(user: user) {
    const headers = { 'content-type': 'application/json' }
    var request = {
      userId: user.userId,
      password: user.password
    }
    const body = JSON.stringify(request);
    return this.http.put<any>(this.root_url + "login", body, { 'headers': headers, 'observe': 'response' });
  }
}